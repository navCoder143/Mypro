from flask import Flask, request, jsonify, render_template_string
import subprocess

app = Flask(__name__)

@app.route('/')
def home():
    return open("index.html").read()

@app.route('/run', methods=['POST'])
def run_code():
    data = request.json
    code = data.get("code", "")
    
    try:
        result = subprocess.run(["python3", "-c", code], capture_output=True, text=True, timeout=5)
        output = result.stdout if result.returncode == 0 else result.stderr
    except Exception as e:
        output = str(e)
    
    return jsonify({"output": output})

@app.route('/pip-modules')
def pip_modules():
    return render_template_string("""
        <html>
        <head><title>PIP Modules</title></head>
        <body style='background:black;color:white;padding:20px;'>
            <button onclick="window.history.back()" style="background:red;color:white;border:none;padding:10px;font-size:18px;">🔙 Back</button>
            <h2>Python Libraries</h2>
            <ul>
                <li><a href='https://pypi.org/project/numpy/' target='_blank' style='color:white;'>Numpy</a></li>
                <li><a href='https://pypi.org/project/pandas/' target='_blank' style='color:white;'>Pandas</a></li>
                <li><a href='https://pypi.org/project/matplotlib/' target='_blank' style='color:white;'>Matplotlib</a></li>
                <li><a href='https://pypi.org/project/scipy/' target='_blank' style='color:white;'>SciPy</a></li>
            </ul>
        </body>
        </html>
    """)

if __name__ == '__main__':
    app.run(debug=True)